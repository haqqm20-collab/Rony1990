// Theme toggle and nav
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('themeToggle');
  const root = document.documentElement;
  const saved = localStorage.getItem('theme');
  if (saved) root.setAttribute('data-theme', saved);
  if (toggle) {
    toggle.addEventListener('click', () => {
      const next = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
      root.setAttribute('data-theme', next);
      localStorage.setItem('theme', next);
      toggle.setAttribute('aria-pressed', String(next === 'dark' ? false : true));
    });
  }

  const navToggle = document.querySelector('.nav-toggle');
  const menu = document.getElementById('menu');
  if (navToggle && menu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      menu.setAttribute('aria-expanded', String(!expanded));
    });
  }

  // Reveal on scroll
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add('in-view');
    });
  }, { threshold: 0.15 });
  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

  // Form validation using Constraint Validation API
  const form = document.getElementById('contact-form');
  if (form) {
    const fields = ['name','email','message'];
    const err = {
      name: document.getElementById('err-name'),
      email: document.getElementById('err-email'),
      message: document.getElementById('err-message')
    };

    function showError(input) {
      const id = input.id;
      if (input.validity.valid) {
        input.setAttribute('aria-invalid', 'false');
        err[id].textContent = '';
        return;
      }
      input.setAttribute('aria-invalid', 'true');
      if (input.validity.valueMissing) {
        err[id].textContent = 'This field is required.';
      } else if (input.validity.typeMismatch && id === 'email') {
        err[id].textContent = 'Enter a valid email address.';
      } else if (input.validity.tooShort) {
        err[id].textContent = `Please lengthen to at least ${input.minLength} characters.`;
      } else if (input.validity.tooLong) {
        err[id].textContent = `Please shorten to ${input.maxLength} characters.`;
      } else {
        err[id].textContent = 'Check this field.';
      }
    }

    fields.forEach(name => {
      const input = document.getElementById(name);
      input.addEventListener('input', () => showError(input));
      input.addEventListener('blur', () => showError(input));
    });

    form.addEventListener('submit', (e) => {
      let ok = true;
      fields.forEach(name => {
        const input = document.getElementById(name);
        if (!input.checkValidity()) { showError(input); ok = false; }
      });
      if (!ok) {
        e.preventDefault();
        document.getElementById('form-status').textContent = 'Please fix the errors and try again.';
        return;
      }
      e.preventDefault();
      document.getElementById('form-status').textContent = 'Thanks! This demo form does not submit.';
    });
  }
});
