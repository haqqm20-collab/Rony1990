# Screenshot Guide

Capture **4–6 screenshots** and drop them in a `screenshots/` folder with the labels below.

1. **Figure 1: Homepage HTML code in VS Code**  
   - Open `index.html` in VS Code. Zoom to 110–120%.  
   - Use your OS screenshot tool.

2. **Figure 2: CSS styling in VS Code**  
   - Open `assets/css/styles.css`. Show media queries and form styles.

3. **Figure 3: JavaScript code in VS Code**  
   - Open `assets/js/main.js`. Highlight the validation logic.

4. **Figure 4: Live homepage view on desktop**  
   - Open `index.html` in Chrome/Edge/Firefox at ~1280 px wide.  
   - Hide bookmarks bar. Take the screenshot.

5. **Figure 5: Site on mobile (simulated)**  
   - Browser DevTools → **Toggle device toolbar**.  
   - Pick a mobile preset (e.g., iPhone SE). Refresh and capture.

6. **Figure 6 (optional): Contact form with validation errors**  
   - Leave fields empty and click **Send (demo)** to show inline errors.
