# Simple Portfolio

A lightweight, accessible three-page portfolio built with **HTML**, **CSS**, and **vanilla JavaScript**.

## Pages
- `index.html` — Home
- `about.html` — About Me
- `contact.html` — Contact form with client-side validation (demo, no backend)

## Features
- Semantic HTML
- Responsive CSS using media queries
- Client-side validation with the Constraint Validation API
- Keyboard-friendly navigation and visible focus styles
- Theme toggle (light/dark)

## Getting started
1. Download this project and open `index.html` in your browser.
2. Edit text (your name, bio, projects) in the HTML files.
3. Optional: change colors in `assets/css/styles.css`.

## Publish with GitHub Pages
- Create a new repository on GitHub.
- Upload these files or push with Git.
- In **Settings › Pages**, set the **Source** to your `main` branch (`/root`).
- Wait 1–2 minutes for the site to build; your URL will look like:
  `https://<your-username>.github.io/<repo-name>/`.

## License
MIT
