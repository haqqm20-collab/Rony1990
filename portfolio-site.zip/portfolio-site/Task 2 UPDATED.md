## 3. Task 2: Work-Related Project Using Tech Sector-Specific Skills

**Focus keyword: web development.**

### Brief intro
You asked for a minimal portfolio using HTML, CSS, and JavaScript. I built a three-page site (Home, About, Contact) with responsive layout and client-side form validation. I used semantic HTML and media queries. I added light/dark theme and small reveal animations.

### Screenshots
- **Figure 1: Homepage HTML code in VS Code** — `index.html` with semantic structure.
- **Figure 2: CSS styling** — `assets/css/styles.css` showing media queries.
- **Figure 3: JavaScript code** — `assets/js/main.js` showing Constraint Validation API.
- **Figure 4: Live homepage view on desktop** — `index.html` at ~1280 px.
- **Figure 5: Site on mobile (simulated)** — Chrome DevTools device toolbar.
- **Figure 6: Contact form errors** — client-side validation messages.

### GitHub
The full project code is available at: **https://github.com/yourusername/portfolio-site**  
(Replace with your actual repository URL after you publish.)

### Short reflection (challenges and fixes)
- I needed a simple way to add form checks without a framework. I used **HTML5 built-in validation** and the **Constraint Validation API** for accessible error messages (Mozilla, 2025).
- Making the layout work on small screens first was easier. I added **CSS media queries** and tested at narrow and wide widths (Mozilla, 2025).
- I kept to **WCAG 2.2** basics: labels, focus styles, keyboard access. I did manual checks against the WAI guidance (W3C, 2024).

### References (Harvard)
- Mozilla (2025) *Client-side form validation*. MDN Web Docs. Available at: https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Form_validation (Accessed: 15 August 2025).
- Mozilla (2025) *Using media queries*. MDN Web Docs. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries/Using_media_queries (Accessed: 15 August 2025).
- W3C (2024) *Web Content Accessibility Guidelines (WCAG) 2.2*. Available at: https://www.w3.org/TR/WCAG22/ (Accessed: 15 August 2025).
- GitHub Docs (n.d.) *Configuring a publishing source for your GitHub Pages site*. Available at: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site (Accessed: 15 August 2025).
